export const environment = {
  production: true,
  baseUrl: 'http://3.250.35.159:8080'
};
